<?php

namespace App\Http\Controllers;
use App\Models\Enseignants;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

class EnseignantController extends Controller
{

    public static function index(Request $r) {
       $val = Enseignants::all();
        return view('ensignants.index', 
            [
                'teachers' => $val
            ]
        );
    }

    public static function store()
    {
        $data = request() -> validate(
            [
                'nom' => 'required|min:5',
                'prenom' => 'required|min:5',
                'cin' => 'required|numeric|min:1000000|max:99999999',
                'email' => 'required|email|unique:Enseignants,email',
                'password' => 'required|min:5',
                'chef' => 'required'   
            ]
        );
        // $data = $request->validated();
        // $data['password'] = Hash::make($request->cin);

        if (request()->hasFile('photo')) {
            $photo = Storage::disk('enseignant')->put('', request()->file('photo'));
            $data['photo'] = $photo;
        }
        if ($data['chef'] == "true") {
            $data['chef'] = true;
        } else {
            $data['chef'] = false;
        }

        $data['password'] = Hash::make($data['password']);
        Enseignants::create($data);

        return redirect('/index_ensignant')
            ->with('success', "L'enseignant a été crée");
    }

    public static function destroy($id) {
        $teach = Enseignants::find($id);
        $teach -> delete();
        return redirect('/index_ensignant')
        ->with('success', "L'ensignant a été suprrimée avec succees");
    }

    public static function edit($id) {
        $teach = Enseignants::find($id);
        return view('ensignants.edit', [
            'teach' => $teach
        ]);
    }

    public static function update($id) {
        $teach = Enseignants::find($id);
        $data = request() -> validate(
            [
                'nom' => 'required|min:5',
                'prenom' => 'required|min:5',
                'email' => "unique:users,email, $id,id",
                'password' => 'required|min:5',
                'chef' => 'required'   
            ]
        );
        if ($data['chef'] == "false") {
            $data['chef'] = 0;
        } else {
            $data['chef'] = 1;
        }
        if (request() -> hasFile('photo')) {
            $photo = Storage::disk('enseignant') -> put('', request() -> file('photo'));
            $data['photo'] = $photo;
        }
        $teach -> update($data);
        return redirect('/index_ensignant')
        ->with('success', "L'ensignant a été modifiée avec succees");
    }

    public static function show($id) {
        return 'na3den jad bouk';
        $teach = Enseignants::find($id);
        // return view('ensignants.show', [
        //     'teach' => $teach
        // ]);
    }
}
