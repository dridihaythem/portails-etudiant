<?php

namespace App\Http\Requests\enseignant;

use Illuminate\Foundation\Http\FormRequest;

class CreateEnseignantRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            // 'classe_id' => 'required|numeric',
            // 'cin' => 'required|numeric|unique:students,cin',
            'nom' => 'required|min:3|max:20',
            'prenom' => 'required|min:3|max:20',
            // 'photo' => 'sometimes|image',
            // 'birthday' => 'required|date',
            // 'address' => 'required',
            // 'phone' => 'sometimes',
        ];
    }

    // public function attributes()
    // {
    //     return [
    //         'first_name' => 'nom',
    //         'last_name' => 'prenom',
    //     ];
    // }
}
