
<?php $__env->startSection('title','Modifier un etudiant'); ?>
<?php $__env->startPush('css'); ?>
<style>
    th {
        width: 250px;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="card card-primary">
    <div class="card-header">
        <h3 class="card-title">
            <i class='fa-solid fa-eye'></i>
            Détails de l'enseignant
        </h3>
    </div>

    <div class="card-body">

        <table class="table table-striped table-bordered mb-3">
            <tbody>
                <tr>
                    <th>Numéro Inscritption : </th>
                    <td><?php echo e($teach->id); ?></td>
                </tr>
                <tr>
                    <th>CIN : </th>
                    <td><?php echo e($teach->cin); ?></td>
                </tr>
                <tr>
                    <th>Nom : </th>
                    <td><?php echo e($teach->nom); ?></td>
                </tr>
                <tr>
                    <th>Prénom : </th>
                    <td><?php echo e($teach->prenom); ?></td>
                </tr>
                <tr>
                    <th>Photo : </th>
                    <td>
                        <img src="<?php echo e($teach -> photo ? asset('storage/app/public/images/enseignant/'.$teach->photo) : asset('storage/app/public/images/enseignant/enseignant-a-mi-carriere-780x470.jpg')); ?>" class="rounded-pill" width="150px" height="150px">
                    </td>
                </tr>
                <tr>
                    <th>Date création : </th>
                    <td><?php echo e($teach->created_at); ?></td>
                </tr>
                <tr>
                    <th>Date de dernière mise à jour : </th>
                    <td><?php echo e($teach->updated_at); ?></td>
                </tr>
            </tbody>
        </table>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\frameworkxamp\project\projet-integration-v2\projet-integration\resources\views/ensignants/show.blade.php ENDPATH**/ ?>