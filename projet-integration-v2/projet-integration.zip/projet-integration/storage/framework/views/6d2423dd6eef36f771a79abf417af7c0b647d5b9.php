
<?php $__env->startSection('title','Modifier un etudiant'); ?>
<?php $__env->startPush('css'); ?>
<style>
    th {
        width: 250px;
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="card card-primary">
    <div class="card-header">
        <h3 class="card-title">
            <i class='fa-solid fa-eye'></i>
            Détails de l'étudiant
        </h3>
    </div>

    <div class="card-body">

        <table class="table table-striped table-bordered mb-3">
            <tbody>
                <tr>
                    <th>Numéro Inscritption : </th>
                    <td><?php echo e($student->id); ?></td>
                </tr>
                <tr>
                    <th>CIN : </th>
                    <td><?php echo e($student->cin); ?></td>
                </tr>
                <tr>
                    <th>Classe : </th>
                    <td><span class="badge badge-primary"><?php echo e($student->classe->name); ?></span></td>
                </tr>
                <tr>
                    <th>Nom : </th>
                    <td><?php echo e($student->first_name); ?></td>
                </tr>
                <tr>
                    <th>Prénom : </th>
                    <td><?php echo e($student->last_name); ?></td>
                </tr>
                <tr>
                    <th>Date de naissance : </th>
                    <td><?php echo e($student->birthday); ?></td>
                </tr>
                <tr>
                    <th>Addresse : </th>
                    <td><?php echo e($student->address); ?></td>
                </tr>
                <tr>
                    <th>Num téléphone : </th>
                    <td><?php echo e($student->phone); ?></td>
                </tr>
                <tr>
                    <th>Photo : </th>
                    <td>
                        <img src="<?php echo e($student->photo); ?>" class="rounded-pill" width="150px" height="150px">
                    </td>
                </tr>
                <tr>
                    <th>Date création : </th>
                    <td><?php echo e($student->created_at); ?></td>
                </tr>
                <tr>
                    <th>Date de dernière mise à jour : </th>
                    <td><?php echo e($student->updated_at); ?></td>
                </tr>
            </tbody>
        </table>

        <a class='btn btn-sm btn-secondary mr-1' href="<?php echo e(route('students.index')); ?>">
            <i class="fa-solid fa-rotate-left"></i>
            Retour à la liste des etudiants
        </a>

        <a class='btn btn-sm btn-success mr-1' href="<?php echo e(route('students.edit', $student->id)); ?>">
            <i class='fa-solid fa-pen-to-square'></i>
            Modifier
        </a>

        <form class='d-inline-block' method='post' action="<?php echo e(route('students.destroy', $student->id)); ?>">
            <input name='_method' value='DELETE' type='hidden'>
            <button class='btn btn-sm btn-danger'>
                <i class='fa-solid fa-trash'></i> Supprimer
            </button>
        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\frameworkxamp\project\projet-integration-v2\projet-integration\resources\views/students/show.blade.php ENDPATH**/ ?>