
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un etudiant | Laravel</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link href="https://adminlte.io/themes/v3/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css"
    rel="stylesheet" />
  
</head>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">

        <nav class="main-header navbar navbar-expand navbar-white navbar-light mb-2">
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button">
                <i class="fas fa-bars"></i>
            </a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
            <a href="#" class="nav-link">Acceuil</a>
        </li>
    </ul>
</nav>
        <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <div class="sidebar">

        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="image">
                <img src="https://adminlte.io/themes/v3/dist/img/user2-160x160.jpg" class="img-circle elevation-2"
                    alt="User Image">
            </div>
            <div class="info">
                <a href="#" class="d-block">User</a>
            </div>
        </div>

        <div class="form-inline">
            <div class="input-group" data-widget="sidebar-search">
                <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
                <div class="input-group-append">
                    <button class="btn btn-sidebar">
                        <i class="fas fa-search fa-fw"></i>
                    </button>
                </div>
            </div>
        </div>

        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">

                <li class="nav-item">
                    <a href="http://127.0.0.1:8000/statistic" class="nav-link">
                        <i class="nav-icon fa-solid fa-chart-area"></i>
                        <p>
                            Statistiques
                        </p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa-solid fa-building-columns"></i>
                        <p>
                            Les Départements
                            <i class="fas fa-angle-left right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="http://127.0.0.1:8000/department" class="nav-link">
                                <i class="fas fa-solid fa-list nav-icon"></i>
                                <p>La liste des départements</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="http://127.0.0.1:8000/department/create" class="nav-link">
                                <i class="fa fa-circle-plus nav-icon"></i>
                                <p>Ajouter un département</p>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-copy"></i>
                        <p>
                            Les Specialités
                            <i class="fas fa-angle-left right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="http://127.0.0.1:8000/specialite" class="nav-link">
                                <i class="fas fa-solid fa-list nav-icon"></i>
                                <p>La liste des Specialités</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="http://127.0.0.1:8000/specialite/create" class="nav-link">
                                <i class="fa fa-circle-plus nav-icon"></i>
                                <p>Ajouter une specialité</p>
                            </a>
                        </li>
                    </ul>
                </li>


                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fa-solid fa-users"></i>
                        <p>
                            Les classes
                            <i class="fas fa-angle-left right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="http://127.0.0.1:8000/classe" class="nav-link">
                                <i class="fas fa-solid fa-list nav-icon"></i>
                                <p>La liste des Classes</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="http://127.0.0.1:8000/classe/create" class="nav-link">
                                <i class="fa fa-circle-plus nav-icon"></i>
                                <p>Ajouter un classe</p>
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-copy"></i>
                        <p>
                            Les Etudiants
                            <i class="fas fa-angle-left right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="http://127.0.0.1:8000/students" class="nav-link">
                                <i class="fas fa-solid fa-list nav-icon"></i>
                                <p>La liste des etudiants</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="http://127.0.0.1:8000/students/create" class="nav-link">
                                <i class="fa fa-circle-plus nav-icon"></i>
                                <p>Ajouter un etudiant</p>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>

    </div>

</aside>
        <div class="content-wrapper">

            <section class="content">
                <div class="container-fluid">
                    <div class="card card-primary">
    <div class="card-header">
        <h3 class="card-title">
            <i class="fa fa-circle-plus"></i>
            Envoyer un email
        </h3>
    </div>

    <div class="card-body">
        <form action="  <?php echo e(route('send.email')); ?>" method="POST">
            <input type="hidden" name="_token" value="30bdz9yFoJtXYITIi4Uf2uiUKZFlbomjZFbohvIM">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <!--  <label>Classe <span class="text-danger">*</span> :</label>
                <select class="form-control select2" name="classe_id">
                                        <option  value="1">
                        TI11
                    </option>
                                        <option  value="2">
                        TI12
                    </option>
                                        <option  value="3">
                        TI13
                    </option>
                                        <option  value="4">
                        DSI21
                    </option>
                                        <option  value="5">
                        DSI22
                    </option>
                                        <option  value="6">
                        RES21
                    </option>
                                        <option  value="7">
                        SEM21
                    </option>
                                        <option  value="8">
                        DSI31
                    </option>
                                        <option  value="9">
                        DSI32
                    </option>
                                        <option  value="10">
                        RES31
                    </option>
                                        <option  value="11">
                        SEM31
                    </option>
                                        <option  value="12">
                        TI11
                    </option>
                                        <option  value="13">
                        TI12
                    </option>
                                        <option  value="14">
                        TI13
                    </option>
                                        <option  value="15">
                        DSI21
                    </option>
                                        <option  value="16">
                        DSI22
                    </option>
                                        <option  value="17">
                        RES21
                    </option>
                                        <option  value="18">
                        SEM21
                    </option>
                                        <option  value="19">
                        DSI31
                    </option>
                                        <option  value="20">
                        DSI32
                    </option>
                                        <option  value="21">
                        RES31
                    </option>
                                        <option  value="22">
                        SEM31
                    </option>
                                        <option  value="23">
                        DSI22
                    </option>
                                    </select>-->
                            </div>

         

            <div class="form-group">
                <label>Nom <span class="text-danger">*</span> :</label>
                <input type="text" name="name" value="<?php echo e(old ('name')); ?>"
                    class="form-control " placeholder="Dhawadi">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
            

            <div class="form-group">
                <label>Email<span class="text-danger">*</span> :</label>
                <input type="text" name="email" value="<?php echo e(old ('email')); ?>"
                    class="form-control "
                    placeholder="Enter your email">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                <label>Subject <span class="text-danger">*</span> :</label>
                <input type="text" name="subject" value="<?php echo e(old ('subject')); ?>"
                    class="form-control " placeholder="subject">
                    <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

            <div class="form-group">
                <label>Message<span class="text-danger">*</span> :</label>
                <textarea type="text" name="message" value="<?php echo e(old ('message')); ?>"
                    class="form-control "  cols="4" rows="4" placeholder="message"></textarea>
                    <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>                


            <button class="btn btn-success">Envoyer</button>
        </form>
    </div>
</div>
                </div>
            </section>

        </div>

        <footer class="main-footer">
    <strong>Copyright &copy; 2022.</strong>
    All rights reserved.
</footer>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2({
            theme: 'bootstrap4'
        })
    });
</script>
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</body>

</html><?php /**PATH C:\frameworkxamp\project\projet-integration-v2\projet-integration\resources\views/contactForm.blade.php ENDPATH**/ ?>