<?php if(Session::has('success')): ?>
<div class="alert alert-success" role="alert">
    <i class="fa-solid fa-circle-check"></i>
    <?php echo e(Session::get('success')); ?>

</div>
<?php endif; ?><?php /**PATH C:\frameworkxamp\project\projet-integration-v2\projet-integration\resources\views/partials/alert.blade.php ENDPATH**/ ?>