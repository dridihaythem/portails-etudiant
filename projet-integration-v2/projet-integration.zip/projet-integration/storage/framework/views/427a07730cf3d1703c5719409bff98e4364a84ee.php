<footer class="main-footer">
    <strong>Copyright &copy; 2022.</strong>
    All rights reserved.
</footer><?php /**PATH C:\frameworkxamp\project\projet-integration-v2\projet-integration\resources\views/partials/footer.blade.php ENDPATH**/ ?>