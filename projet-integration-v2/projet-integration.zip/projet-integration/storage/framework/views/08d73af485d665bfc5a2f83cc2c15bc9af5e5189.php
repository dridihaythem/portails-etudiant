
<?php $__env->startSection('title','La liste des etudiants'); ?>
<?php $__env->startSection('content'); ?>
<div class="card card-primary">
    <div class="card-header">
        <h3 class="card-title">
            <i class="fa-solid fa-list"></i>
            La liste des enseignants
        </h3>
    </div>

    <div class="card-body">

        <?php echo $__env->make('partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div id="example1_wrapper" class="example1_wrapper"></div>
        <table id="datatable" class="table atable-bordered table-striped">
            <thead>
                <tr>
                    <th style="border-bottom: 1px solid black">ID</th>
                    <th style="border-bottom: 1px solid black">CIN</th>
                    <th style="border-bottom: 1px solid black">Nom</th>
                    <th style="border-bottom: 1px solid black">Prenom</th>
                    <th style="border-bottom: 1px solid black">Email</th>
                    <th style="border-bottom: 1px solid black">Creé le</th>
                    <th style="border-bottom: 1px solid black">Modifé le</th>
                    <th class="sorting" style="width: 300px; border-bottom: 1px solid black;">?</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($teach -> id); ?></th>
                    <th><?php echo e($teach -> cin); ?></th>
                    <th><?php echo e($teach -> nom); ?></th>
                    <th><?php echo e($teach -> prenom); ?></th>
                    <th><?php echo e($teach -> email); ?></th>
                    <th><?php echo e($teach -> created_at -> format("d/m/Y")); ?></th>
                    <th><?php echo e($teach -> updated_at -> format("d/m/Y")); ?></th>
                    <th style="width: 300px; display: flex; justify-content: space-between">
                        <form id="<?php echo e($teach -> id); ?>" action="/destroy/<?php echo e($teach -> id); ?>" onsubmit="delteItem()" method="post" enctype="multipart/form-data">
                        <!-- <input name='_method' value='DELETE' type='hidden'> -->
                            <?php echo e(csrf_field()); ?>

                            <input type="submit" class='btn btn-sm btn-danger' value="supprimer">
                                <i class='fa-solid fa-trash'></i>
                            
                        </form>
                        
                        <a class='btn btn-sm btn-primary mr-1' href="/teachers/<?php echo e($teach -> id); ?>">
                            <i class='fa-solid fa-eye'></i>
                            Détails
                        </a>

                        <a class='btn btn-sm btn-success mr-1' href="/edit/<?php echo e($teach -> id); ?>"  style="width: 100px">
                            <i class='fa-solid fa-pen-to-square'></i>
                                Modifier
                        </a>
                </th>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    function delteItem(event){
        // if (confirm("Press a button!")) {
        //     window.open('/destroy', '_blank');
        // }
    }
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\frameworkxamp\project\projet-integration-v2\projet-integration\resources\views/ensignants/index.blade.php ENDPATH**/ ?>