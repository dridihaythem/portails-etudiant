@extends('layouts.app')
@section('title','Modifier un etudiant')
@push('css')
<style>
    th {
        width: 250px;
    }
</style>
@endpush
@section('content')
<div class="card card-primary">
    <div class="card-header">
        <h3 class="card-title">
            <i class='fa-solid fa-eye'></i>
            Détails de l'enseignant
        </h3>
    </div>

    <div class="card-body">

        <table class="table table-striped table-bordered mb-3">
            <tbody>
                <tr>
                    <th>Numéro Inscritption : </th>
                    <td>{{ $teach->id }}</td>
                </tr>
                <tr>
                    <th>CIN : </th>
                    <td>{{ $teach->cin }}</td>
                </tr>
                <tr>
                    <th>Nom : </th>
                    <td>{{ $teach->nom }}</td>
                </tr>
                <tr>
                    <th>Prénom : </th>
                    <td>{{ $teach->prenom }}</td>
                </tr>
                <tr>
                    <th>Photo : </th>
                    <td>
                        <img src="{{ $teach -> photo ? asset('storage/app/public/images/enseignant/'.$teach->photo) : asset('storage/app/public/images/enseignant/enseignant-a-mi-carriere-780x470.jpg')}}" class="rounded-pill" width="150px" height="150px">
                    </td>
                </tr>
                <tr>
                    <th>Date création : </th>
                    <td>{{ $teach->created_at }}</td>
                </tr>
                <tr>
                    <th>Date de dernière mise à jour : </th>
                    <td>{{ $teach->updated_at }}</td>
                </tr>
            </tbody>
        </table>

    </div>
</div>
@endsection