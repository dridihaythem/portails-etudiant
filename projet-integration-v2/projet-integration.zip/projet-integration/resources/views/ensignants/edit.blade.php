@extends('layouts.app')
@section('title','Modifier un etudiant')
<?php
    use Illuminate\Support\Facades\Crypt;

?>
@push('css')
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link href="https://adminlte.io/themes/v3/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css"
    rel="stylesheet" />
@endpush
@push('js')
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2({
            theme: 'bootstrap4'
        })
    });
</script>
@endpush
@section('content')
<div class="card card-primary">
    <div class="card-header">
        <h3 class="card-title">
            <i class="fa-solid fa-pen-to-square"></i>
            Modifier un ensignant
        </h3>
    </div>

    <div class="card-body">
        <form action="/update/{{$teach -> id}}" method="post" enctype="multipart/form-data">
            @csrf
            @method('put')

            <div class="form-group">
                <label>Cin</label>
                <input type="number" disabled name="cin" value="{{ $teach->cin }}"
                    class="form-control @error('cin') is-invalid @enderror" placeholder="11400400">
                @error('cin')
                <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>

            <div class="form-group">
                <label>Nom <span class="text-danger">*</span> :</label>
                <input type="text" name="nom" value="{{ $teach->nom }}"
                    class="form-control @error('nom') is-invalid @enderror" placeholder="....">
                @error('nom')
                <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>

            <div class="form-group">
                <label>Prenom <span class="text-danger">*</span> :</label>
                <input type="text" name="prenom" value="{{ $teach->prenom }}"
                    class="form-control @error('prenom') is-invalid @enderror" placeholder="................">
                @error('prenom')
                <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>

            <div class="form-group">
                <label>Email <span class="text-danger">*</span> :</label>
                <input type="text" name="email" value="{{ $teach->email }}"
                    class="form-control @error('email') is-invalid @enderror" placeholder="................">
                @error('email')
                <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>

            <div class="form-group">
                <label>password(resaisir l'ancienne mot de passe ou entrer une nouvelle mot de passe) <span class="text-danger">*</span> :</label>
                <input type="password" name="password" value="" class="form-control @error('password') is-invalid @enderror" placeholder="">
                @error('password')
                <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>

            <div class="form-group">
                <label>Image :</label>
                <input type="file" name="photo" class=" form-control @error('photo') is-invalid @enderror">
                @error('photo')
                <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>

            <div class="form-group">
                <label>Classe <span class="text-danger">*</span> :</label>
                <select class="form-control select2" name="chef">
                    <option>choisir</option>
                    <option @selected($teach->chef) == 1 value="true">
                        chef
                    </option>
                    <option @selected($teach -> chef == 0) value = "false">
                        !chef
                    </option>
                </select>
                @error('chef')
                <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
            <button class="btn btn-success">Modifier</button>
        </form>
    </div>
</div>
@endsection