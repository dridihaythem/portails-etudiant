@extends('layouts.app')
@section('title','La liste des etudiants')
@section('content')
<div class="card card-primary">
    <div class="card-header">
        <h3 class="card-title">
            <i class="fa-solid fa-list"></i>
            La liste des enseignants
        </h3>
    </div>

    <div class="card-body">

        @include('partials.alert')

        <div id="example1_wrapper" class="example1_wrapper"></div>
        <table id="datatable" class="table atable-bordered table-striped">
            <thead>
                <tr>
                    <th style="border-bottom: 1px solid black">ID</th>
                    <th style="border-bottom: 1px solid black">CIN</th>
                    <th style="border-bottom: 1px solid black">Nom</th>
                    <th style="border-bottom: 1px solid black">Prenom</th>
                    <th style="border-bottom: 1px solid black">Email</th>
                    <th style="border-bottom: 1px solid black">Creé le</th>
                    <th style="border-bottom: 1px solid black">Modifé le</th>
                    <th class="sorting" style="width: 300px; border-bottom: 1px solid black;">?</th>
                </tr>
            </thead>
            <tbody>
                @foreach($teachers as $teach)
                <tr>
                    <th>{{$teach -> id}}</th>
                    <th>{{$teach -> cin}}</th>
                    <th>{{$teach -> nom}}</th>
                    <th>{{$teach -> prenom}}</th>
                    <th>{{$teach -> email}}</th>
                    <th>{{$teach -> created_at -> format("d/m/Y")}}</th>
                    <th>{{$teach -> updated_at -> format("d/m/Y")}}</th>
                    <th style="width: 300px; display: flex; justify-content: space-between">
                        <form id="{{$teach -> id}}" action="/destroy/{{$teach -> id}}" onsubmit="delteItem()" method="post" enctype="multipart/form-data">
                        <!-- <input name='_method' value='DELETE' type='hidden'> -->
                            {{csrf_field()}}
                            <input type="submit" class='btn btn-sm btn-danger' value="supprimer">
                                <i class='fa-solid fa-trash'></i>
                            
                        </form>
                        
                        <a class='btn btn-sm btn-primary mr-1' href="/teachers/{{$teach -> id}}">
                            <i class='fa-solid fa-eye'></i>
                            Détails
                        </a>

                        <a class='btn btn-sm btn-success mr-1' href="/edit/{{$teach -> id}}"  style="width: 100px">
                            <i class='fa-solid fa-pen-to-square'></i>
                                Modifier
                        </a>
                </th>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection

@push('css')
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
@endpush

@push('js')
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    function delteItem(event){
        // if (confirm("Press a button!")) {
        //     window.open('/destroy', '_blank');
        // }
    }
</script>
@endpush

